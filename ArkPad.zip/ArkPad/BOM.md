BILLING OF MATERIALZZ ArkPad

-1x Seed Xiao RP2040 DIP
-10x Cherry MX 1.00u
-2 LED SK6812 MINI
-3D printed Case (ArkPad Base & ArkPad top)
-4x 3.4mm fastening screws